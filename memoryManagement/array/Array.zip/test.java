package memoryManagement.array;

public class test {
    public static void main(String[] args) 
    {
        // int [] arr = new int[5];
        // arr[0]=10;
        // arr[1]=20;
        // arr[2]=30;
        // arr[3]=40;
        // arr[4]=50;
        // arr[2]=100;
        // System.out.println(arr[2]);

        // int[] arr = new int[] {10,20,30,40,50,60};
        // System.out.println(arr[5]);

        // int [] arr ={10,20,30};
        // System.out.println(arr[1]);

        // int arr[] = {10,20,30};
        // System.out.println(arr[1]);

        // int [] arr = new int[] {1,2,3};
        // System.out.println(arr[1]);

        // int arr[] = new int[]{1,2,3};
        // System.out.println(arr[1]);


    }
}
