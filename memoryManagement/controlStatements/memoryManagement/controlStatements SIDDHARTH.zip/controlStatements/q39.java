package memoryManagement.controlStatements;

public class q39 {
    public static void main(String[] args) {
        //39. Write a Java program to create a simple calculator
        int num1=20;
        int num2=10;

        int add= num1+num2;
        int subtract= num1-num2;
        int multiply= num1*num2;
        int divide= num1/num2;

        System.out.println("num1+num2="+ add);
        System.out.println("num1-num2=" + subtract);
        System.out.println("num1*num2=" + multiply);
        System.out.println("num1/num2=" + divide);

    }
    
}
