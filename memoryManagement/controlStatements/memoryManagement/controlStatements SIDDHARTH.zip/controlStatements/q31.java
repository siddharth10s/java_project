package memoryManagement.controlStatements;

public class q31 {
    public static void main(String[] args) {
        //31. Find the absolute value of a number entered through the keyboard
        int number=45;
        double absoluteValue = Math.abs(number);
        
        System.out.println("The absolute value of " + number + " is: " + absoluteValue);
        
    }
}
