package memoryManagement.controlStatements;

public class q28 {
    public static void main(String[] args) {
//         28. A five-digit number is entered through the keyboard. Write a program to obtain the 
// reversed number and to determine whether the original and reversed numbers are equal 
// or not
        int a;
    }
}
