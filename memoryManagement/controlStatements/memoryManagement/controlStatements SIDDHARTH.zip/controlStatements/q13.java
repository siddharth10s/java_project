package memoryManagement.controlStatements;

public class q13 
{
    public static void main(String[] args) {
        //13. Write a program to count total number of notes in given amount

        int amount=500;

        
    }
    
}
